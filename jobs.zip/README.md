# business-ims-server

## License

This project is licensed under a custom license.  
For more details, please refer to the [LICENSE.md](./LICENSE.md) file.

Unauthorized use, distribution, or modification of this project is prohibited without explicit permission from the author.
